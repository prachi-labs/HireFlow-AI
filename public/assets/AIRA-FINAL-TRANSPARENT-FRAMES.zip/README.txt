AIRA — TRANSPARENT SCROLL-ANIMATION FRAMES

300 sequential WebP frames with alpha transparency.
Files: aira0001.webp through aira0300.webp
Resolution: 1280 x 720 (source video native resolution)
Frame sequence: 30 FPS, 10 seconds
Background: green screen removed by automated chroma key.
Gemini sparkle/logo: fixed lower-right area cleared to transparency in all frames.

Note: This is an automated matte. Inspect fine hair edges before production use.
